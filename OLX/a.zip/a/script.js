function showSurprise(flowerIndex) {
    const messages = [
        "В тебе найгарніша посмішка у світі",
        "Ти світиш як сонечко в моєму житті, я люблю це",
        "В тебе все вийде, я в тебе вірю, ти - найкраща"
    ];
    const surprise = document.getElementById("surprise");
    surprise.textContent = messages[flowerIndex]; // Show the message for the clicked flower
    surprise.style.marginTop = "20px";
    surprise.style.fontSize = "18px";
    surprise.style.color = "#ff69b4";

}
